﻿// Copyright lurongjiu 2026 All Rights Reserved.

//#if WITH_EDITOR
#include "UK2Node_AsyncForEach.h"
#include "EdGraphSchema_K2.h"
#include "AsyncForEachLoop.h"
#include "AsyncFor.h"
#include "GenericTypeHelper.h"


UK2Node_AsyncForEach::UK2Node_AsyncForEach(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	//匹配对应的激活函数,否则不会调用其Activate,匹配为父类
	ProxyActivateFunctionName = GET_FUNCTION_NAME_CHECKED(UBlueprintAsyncActionBase, Activate);

	UpdateProxys();
}



void UK2Node_AsyncForEach::AllocateDefaultPins()
{
	Super::AllocateDefaultPins();

	//添加Mode选择
	UEdGraphPin* ModePin = CreatePin(EGPD_Input,UEdGraphSchema_K2::PC_Byte,StaticEnum<EForEachMode>(),TEXT("Mode"));

	ModePin->DefaultValue =StaticEnum<EForEachMode>()->GetNameStringByValue((int64)LastForEachMode);
	ModePin->bNotConnectable = true;

	//添加Type选择
	UEdGraphPin* TypePin = CreatePin(EGPD_Input,UEdGraphSchema_K2::PC_Boolean,TEXT("PureCount"));

	TypePin->DefaultValue = PureCount ? TEXT("true") : TEXT("false");
	TypePin->bNotConnectable = true;
	
	//隐藏Then引脚
	/*if(UEdGraphPin* ThenPin = GetThenPin())
	{
		ThenPin->bNotConnectable = true;
		ThenPin->bHidden = true;
	}*/

	//把Completed引脚移到最后
	if(UEdGraphPin* CompletedPin = FindPinChecked(TEXT("Completed")))
	{
		Pins.RemoveSingle(CompletedPin);
		Pins.Add(CompletedPin);
	}
}

void UK2Node_AsyncForEach::ExpandNode(class FKismetCompilerContext& CompilerContext, UEdGraph* SourceGraph)
{
	//编译前重新读取节点状态
	//自己加的节点不属于函数,编译时会匹配失败导致报错,移除(此时移除节点不会从Widget上移除)
	if(UEdGraphPin* ModePin = FindPinChecked(TEXT("Mode")))
	{
		RemovePin(ModePin);
	}
	if(UEdGraphPin* TypePin = FindPinChecked(TEXT("PureCount")))
	{
		RemovePin(TypePin);
	}

	Super::ExpandNode(CompilerContext, SourceGraph);
}

FText UK2Node_AsyncForEach::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	if(TitleType == ENodeTitleType::MenuTitle)
	{
		return FText::FromString(TEXT("ForEach_AsyncTask_Helper"));
	}
	FString Title = TEXT("ForEach_AsyncTask");
	FString Type = PureCount ? TEXT("Count") : TEXT("Array");
	FString Mode;

	
	if(LastForEachMode == EForEachMode::WaitRun)
	{
		Mode = "WaitRun";
	}
	else if(LastForEachMode == EForEachMode::WaitTime)
	{
		Mode = "WaitTime";
	}
	else if(LastForEachMode == EForEachMode::TimerLoop)
	{
		Mode = "TimerLoop";
	}
	else if(LastForEachMode == EForEachMode::Next)
	{
		Mode = "Next";
	}
	
	FString Result = FString::Printf(TEXT("%s_%s_%s"), *Title, *Type, *Mode);
	
 	return FText::FromString(Result);
}

void UK2Node_AsyncForEach::UpdateProxys()
{
	if(!PureCount)
	{
		ProxyClass = UAsyncForLoop_GenericVarContainer::StaticClass();
		ProxyFactoryClass = UAsyncForLoop_GenericVarContainer::StaticClass();
		if(LastForEachMode == EForEachMode::WaitRun)
		{
			ProxyFactoryFunctionName = GET_FUNCTION_NAME_CHECKED(UAsyncForLoop_GenericVarContainer,AsyncForEach_GenericVarContainer_WaitRun);
		}
		else if(LastForEachMode == EForEachMode::WaitTime)
		{
			ProxyFactoryFunctionName = GET_FUNCTION_NAME_CHECKED(UAsyncForLoop_GenericVarContainer,AsyncForEach_GenericVarContainer_WaitTime);
		}
		else if(LastForEachMode == EForEachMode::TimerLoop)
		{
			ProxyFactoryFunctionName = GET_FUNCTION_NAME_CHECKED(UAsyncForLoop_GenericVarContainer,AsyncForEach_GenericVarContainer_TimerLoop);
		}
		else if(LastForEachMode == EForEachMode::Next)
		{
			ProxyFactoryFunctionName = GET_FUNCTION_NAME_CHECKED(UAsyncForLoop_GenericVarContainer,AsyncForEach_GenericVarContainer_Next);
		}
	}
	else
	{
		ProxyClass = UAsyncForLoop_PureCount::StaticClass();
		ProxyFactoryClass = UAsyncForLoop_PureCount::StaticClass();
		if(LastForEachMode == EForEachMode::WaitRun)
		{
			ProxyFactoryFunctionName = GET_FUNCTION_NAME_CHECKED(UAsyncForLoop_PureCount,AsyncForEach_PureCount_WaitRun);
		}
		else if(LastForEachMode == EForEachMode::WaitTime)
		{
			ProxyFactoryFunctionName = GET_FUNCTION_NAME_CHECKED(UAsyncForLoop_PureCount,AsyncForEach_PureCount_WaitTime);
		}
		else if(LastForEachMode == EForEachMode::TimerLoop)
		{
			ProxyFactoryFunctionName = GET_FUNCTION_NAME_CHECKED(UAsyncForLoop_PureCount,AsyncForEach_PureCount_TimerLoop);
		}
		else if(LastForEachMode == EForEachMode::Next)
		{
			ProxyFactoryFunctionName = GET_FUNCTION_NAME_CHECKED(UAsyncForLoop_PureCount,AsyncForEach_PureCount_Next);
		}
	}
}



//有任何引脚链接发生变化,在此修改传参的引脚变量类型
/*void UK2Node_AsyncForEach::NotifyPinConnectionListChanged(UEdGraphPin* Pin)
{
	//从变量呼叫函数时,默认情况会链接到Then,此时将其链接到loopbody并断开Then.
	if(Pin == GetThenPin() && Pin)
	{
		//在删除节点时所有引脚都会会调用该函数.所以必须判断pin链接不为空说明是连接时,否则是删除时
		if (!Pin->LinkedTo.IsEmpty())
		{
			if(UEdGraphPin* TypePin = FindPinChecked(TEXT("LoopBody")))
			{
				if(TypePin->LinkedTo.IsEmpty())
				{
					TypePin->MakeLinkTo(Pin->LinkedTo[0]);
				}
			}
			Pin->BreakAllPinLinks();
		}
	}
}*/

void UK2Node_AsyncForEach::PinDefaultValueChanged(UEdGraphPin* Pin)
{
	Super::PinDefaultValueChanged(Pin);
	
	if (Pin->PinName == "Mode")
	{
		//bool NeedRemake = false;
		if(Pin->DefaultValue == "WaitRun" && LastForEachMode != EForEachMode::WaitRun)
		{
			LastForEachMode = EForEachMode::WaitRun;
			UpdateProxys();
			ReconstructNode();
		}
		else if (Pin->DefaultValue == "WaitTime" && LastForEachMode != EForEachMode::WaitTime)
		{
			LastForEachMode = EForEachMode::WaitTime;
			UpdateProxys();
			ReconstructNode();
		}
		else if (Pin->DefaultValue == "TimerLoop" && LastForEachMode != EForEachMode::TimerLoop)
		{
			LastForEachMode = EForEachMode::TimerLoop;
			UpdateProxys();
			ReconstructNode();
		}
		else if (Pin->DefaultValue == "Next" && LastForEachMode != EForEachMode::Next)
		{
			LastForEachMode = EForEachMode::Next;
			UpdateProxys();
			ReconstructNode();
		}
	}
	
	else if (Pin->PinName == "PureCount")
	{
		if(Pin->DefaultValue == "false" && PureCount)
		{
			PureCount = false;
			UpdateProxys();
			ReconstructNode();
		}
		else if(Pin->DefaultValue == "true" && !PureCount)
		{
			PureCount = true;
			UpdateProxys();
			ReconstructNode();
		}
	}
	//todo:需要断开旧节点链接
}

FText UK2Node_AsyncForEach::GetMenuCategory() const
{
	return FText::FromString("AsyncTaskHelper|Utilities");
}

void UK2Node_AsyncForEach::GetPinHoverText(const UEdGraphPin& Pin, FString& HoverTextOut) const
{
	//暂无语言本地化
	Super::GetPinHoverText(Pin, HoverTextOut);
	if (Pin.PinName == "Mode")
	{
		if(Pin.DefaultValue == "WaitRun")
		{
			HoverTextOut = TEXT("Foreach,call 'wait' to pause,and call 'run' to resumes");
		}
		else if (Pin.DefaultValue == "WaitTime")
		{
			HoverTextOut = TEXT("Foreach,call 'WaitTime' to pause until time over");
		}
		else if (Pin.DefaultValue == "TimerLoop")
		{
			HoverTextOut = TEXT("Foreach,and stay time on every one loopbody");
		}
		else if (Pin.DefaultValue == "Next")
		{
			HoverTextOut = TEXT("Stay on every one loopbody,until call 'Next'");
		}
	}
	if (Pin.PinName == "PureCount")
	{
		if(PureCount)
		{
			HoverTextOut = TEXT("Make a pure counter task without variable");
		}
		else
		{
			HoverTextOut = TEXT("Make a async foreach array task");
		}
	}
}

//------------------------------------------------------------------
UK2Node_AsyncSimpleTask::UK2Node_AsyncSimpleTask(const FObjectInitializer& ObjectInitializer)
{
	//匹配对应的激活函数,否则不会调用其Activate,匹配为父类
	ProxyActivateFunctionName = GET_FUNCTION_NAME_CHECKED(UBlueprintAsyncActionBase, Activate);
	Once = true;

	UpdateProxys();
}

void UK2Node_AsyncSimpleTask::AllocateDefaultPins()
{
	Super::AllocateDefaultPins();

	//添加Type选择
	UEdGraphPin* TypePin = CreatePin(EGPD_Input,UEdGraphSchema_K2::PC_Boolean,TEXT("Once"));

	TypePin->DefaultValue = TEXT("true");
	TypePin->bNotConnectable = true;
}

void UK2Node_AsyncSimpleTask::ExpandNode(class FKismetCompilerContext& CompilerContext, UEdGraph* SourceGraph)
{
	if(UEdGraphPin* TypePin = FindPinChecked(TEXT("Once")))
	{
		RemovePin(TypePin);
	}
	Super::ExpandNode(CompilerContext, SourceGraph);
}

FText UK2Node_AsyncSimpleTask::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	if(TitleType == ENodeTitleType::MenuTitle)
	{
		return FText::FromString(TEXT("SimpleTask_Helper"));
	}
	return Super::GetNodeTitle(TitleType);
}

void UK2Node_AsyncSimpleTask::PinDefaultValueChanged(UEdGraphPin* Pin)
{
	Super::PinDefaultValueChanged(Pin);
	if (Pin->PinName == "Once")
	{
		if(Pin->DefaultValue == "false" && Once)
		{
			Once = false;
			UpdateProxys();
			ReconstructNode();
		}
		else if(Pin->DefaultValue == "true" && !Once)
		{
			Once = true;
			UpdateProxys();
			ReconstructNode();
		}
	}
}

FText UK2Node_AsyncSimpleTask::GetMenuCategory() const
{
	return FText::FromString("AsyncTaskHelper|Utilities");
}

void UK2Node_AsyncSimpleTask::GetPinHoverText(const UEdGraphPin& Pin, FString& HoverTextOut) const
{
	Super::GetPinHoverText(Pin, HoverTextOut);
	if (Pin.PinName == "Once")
	{
		if(!Once)
		{
			HoverTextOut = TEXT("Make a multi-times task");
		}
		else
		{
			HoverTextOut = TEXT("Make a one-time task");
		}
	}
}

void UK2Node_AsyncSimpleTask::UpdateProxys()
{
	if(Once)
	{
		ProxyClass = UAsyncSimpleSingleTaskAction::StaticClass();
		ProxyFactoryClass = UAsyncSimpleSingleTaskAction::StaticClass();
		ProxyFactoryFunctionName = GET_FUNCTION_NAME_CHECKED(UAsyncSimpleSingleTaskAction,SimpleSingleTimeTask);
		
	}
	else
	{
		ProxyClass = UAsyncSimpleMultipleTaskAction::StaticClass();
		ProxyFactoryClass = UAsyncSimpleMultipleTaskAction::StaticClass();
		ProxyFactoryFunctionName = GET_FUNCTION_NAME_CHECKED(UAsyncSimpleMultipleTaskAction,SimpleMultipleTimesTask);
	}
}
//#endif