﻿// Copyright lurongjiu 2026 All Rights Reserved.


#include "GenericTypeHelperNodes.h"

#include "GenericTypeHelperLibrary.h"
#include "BlueprintActionDatabaseRegistrar.h"
#include "BlueprintNodeSpawner.h"
#include "GenericTypeHelper.h"

void UK2Node_GenericVarContainer::GetMenuActions(FBlueprintActionDatabaseRegistrar& ActionRegistrar) const
{
	Super::GetMenuActions(ActionRegistrar);
	UClass* Action = GetClass();
	if (ActionRegistrar.IsOpenForRegistration(Action))
	{
		auto CustomizeLambda = [](UEdGraphNode* NewNode, bool bIsTemplateNode, const FName FunctionName)
		{
			UK2Node_GenericVarContainer* Node = CastChecked<UK2Node_GenericVarContainer>(NewNode);
			UFunction* Function = UGenericTypeHelperLibrary::StaticClass()->FindFunctionByName(FunctionName);
			check(Function);
			Node->SetFromFunction(Function);
		};
		
		UBlueprintNodeSpawner* MakeNodeSpawner = UBlueprintNodeSpawner::Create(GetClass());
		check(MakeNodeSpawner != nullptr);
		MakeNodeSpawner->CustomizeNodeDelegate = UBlueprintNodeSpawner::FCustomizeNodeDelegate::CreateStatic(CustomizeLambda, GET_FUNCTION_NAME_CHECKED(UGenericTypeHelperLibrary, MakeContainerFromVar));
		ActionRegistrar.AddBlueprintAction(Action, MakeNodeSpawner);

		UBlueprintNodeSpawner* GetNodeSpawner = UBlueprintNodeSpawner::Create(GetClass());
		check(GetNodeSpawner != nullptr);
		GetNodeSpawner->CustomizeNodeDelegate = UBlueprintNodeSpawner::FCustomizeNodeDelegate::CreateStatic(CustomizeLambda, GET_FUNCTION_NAME_CHECKED(UGenericTypeHelperLibrary, GetVarFromContainer));
		ActionRegistrar.AddBlueprintAction(Action, GetNodeSpawner);	
	}
}

bool UK2Node_GenericVarContainer::IsConnectionDisallowed(const UEdGraphPin* MyPin, const UEdGraphPin* OtherPin,FString& OutReason) const
{
	bool Result = Super::IsConnectionDisallowed(MyPin, OtherPin, OutReason);
	
	if(MyPin->PinName == "Var")
	{
		//todo:未来支持类型
		if(OtherPin->PinType.IsMap() || OtherPin->PinType.PinCategory == UEdGraphSchema_K2::PC_Delegate || OtherPin->PinType.PinCategory == UEdGraphSchema_K2::PC_Interface)
		{
			Result = true;
		}
	}
	return Result;
}
