﻿// Copyright lurongjiu 2026 All Rights Reserved.
#pragma once


#include "K2Node_CallFunction.h"
#include "GenericTypeHelperNodes.generated.h"


UCLASS()
class UK2Node_GenericVarContainer : public UK2Node_CallFunction
{
	GENERATED_BODY()
public:
	//~ Begin UEdGraphNode Interface
	virtual void GetMenuActions(FBlueprintActionDatabaseRegistrar& ActionRegistrar) const override;
	//~ End UEdGraphNode Interface

	//~ Begin K2Node Interface
	virtual bool IsConnectionDisallowed(const UEdGraphPin* MyPin, const UEdGraphPin* OtherPin, FString& OutReason) const override;
	//~ End K2Node Interface
};
