﻿// Copyright lurongjiu 2026 All Rights Reserved.

#pragma once
//#if WITH_EDITOR
#include "CoreMinimal.h"
#include "AsyncForEachLoop.h"

#include "K2Node_AsyncAction.h"
#include "UK2Node_AsyncForEach.generated.h"


enum class EForEachMode : uint8;
//#endif
//#if WITH_EDITOR
UCLASS()
class UK2Node_AsyncForEach : public UK2Node_BaseAsyncTask
{
	GENERATED_BODY()

public:

	UK2Node_AsyncForEach(const FObjectInitializer& ObjectInitializer);
	virtual void AllocateDefaultPins() override;
	virtual void ExpandNode(class FKismetCompilerContext& CompilerContext, UEdGraph* SourceGraph) override;
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const override;
	//virtual void NotifyPinConnectionListChanged(UEdGraphPin* Pin) override;
	virtual void PinDefaultValueChanged(UEdGraphPin* Pin) override;
	virtual FText GetMenuCategory() const override;
	virtual void GetPinHoverText(const UEdGraphPin& Pin, FString& HoverTextOut) const override;
//#endif
//#if WITH_EDITORONLY_DATA
private:

	//标记变量被序列化,即该变量需在下次启动时保持状态
	UPROPERTY()
	EForEachMode LastForEachMode = EForEachMode::WaitRun;
	UPROPERTY()
	bool PureCount = false;

	void UpdateProxys();
};
//#endif

//#if WITH_EDITOR
UCLASS()
class UK2Node_AsyncSimpleTask : public UK2Node_BaseAsyncTask
{
	GENERATED_BODY()

public:

	UK2Node_AsyncSimpleTask(const FObjectInitializer& ObjectInitializer);
	virtual void AllocateDefaultPins() override;
	virtual void ExpandNode(class FKismetCompilerContext& CompilerContext, UEdGraph* SourceGraph) override;
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const override;
	//virtual void NotifyPinConnectionListChanged(UEdGraphPin* Pin) override;
	virtual void PinDefaultValueChanged(UEdGraphPin* Pin) override;
	virtual FText GetMenuCategory() const override;
	virtual void GetPinHoverText(const UEdGraphPin& Pin, FString& HoverTextOut) const override;
//#endif
	
//#if WITH_EDITORONLY_DATA
private:
	//标记变量需被序列化
	UPROPERTY()
	bool Once = true;

	void UpdateProxys();
};

//#endif