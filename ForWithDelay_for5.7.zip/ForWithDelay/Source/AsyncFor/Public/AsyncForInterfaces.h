﻿// Copyright lurongjiu 2026 All Rights Reserved.
#pragma once
#include "AsyncForInterfaces.generated.h"

class IAsyncForInterfaces_Run;
class FAsyncCompleted;

/**
* Task Interfaces base type
*/
UINTERFACE(MinimalAPI,NotBlueprintable,BlueprintType)
class UAsyncForInterfaces_Base : public UInterface
{
	GENERATED_BODY()
};

class IAsyncForInterfaces_Base
{
	GENERATED_BODY()
public:
	
	/**
	* Make task finish, sometimes will be called auto
	*/
	UFUNCTION(BlueprintCallable, Category = "AsyncTaskHelper|Interfaces", meta = (CompactNodeTitle = "Break"))
	virtual void Break() = 0;
	/**
	* Make task start, sometimes will not called auto
	* @return Reason for if fail
	*/
	UFUNCTION(BlueprintCallable, Category = "AsyncTaskHelper|Interfaces", meta = (CompactNodeTitle = "Start"))
	virtual FString Start() = 0;
	/**
	* If task finished? (handle should no longer be use)
	*/
	UFUNCTION(BlueprintCallable, Category = "AsyncTaskHelper|Interfaces", meta = (CompactNodeTitle = "Finished?"))
	virtual bool IsFinished() = 0;

	//该task是持续存在的,不应该作为子任务加入任何task
	virtual bool IsPersistent() = 0;
	//检查该task是否可被加入taskqueue
	virtual bool AddToTaskCheck(FString& FailReason) = 0;
	//获取该task的complete回调对象,用于绑定
	virtual FAsyncCompleted& GetComplete() = 0;
	//由于用户调用的start有task检查,所以task应调用真start
	virtual void OnStart() = 0;

};

UINTERFACE(MinimalAPI,NotBlueprintable,BlueprintType)
class UAsyncForInterfaces_TaskQueue : public UAsyncForInterfaces_Base
{
	GENERATED_BODY()
};

class IAsyncForInterfaces_TaskQueue : public IAsyncForInterfaces_Base
{
	GENERATED_BODY()
public:
	/**
	* Add a task to queue, and auto start when queue up to if.
	* 
	* @param NewTask	sub task to add
	* @return Reason for if fail
	*/
	UFUNCTION(BlueprintCallable, Category = "AsyncTaskHelper|Interfaces", meta = (CompactNodeTitle = "Add"))
	virtual FString AddTask(TScriptInterface<IAsyncForInterfaces_Base> NewTask) = 0;
};


UINTERFACE(MinimalAPI,NotBlueprintable,BlueprintType)
class UAsyncForInterfaces_General : public UAsyncForInterfaces_Base
{
	GENERATED_BODY()
};

class IAsyncForInterfaces_General : public IAsyncForInterfaces_Base
{
	GENERATED_BODY()
public:

	/**
	* Immediately pauses the current loop and resumes only after the subtask has finished.
	* notice:It will not auto start the sub-task and self.
	* 
	* @param AsyncForTask	sub task to wait
	* @return Reason for if fail
	*/
	UFUNCTION(BlueprintCallable, Category = "AsyncTaskHelper|Interfaces", meta = (CompactNodeTitle = "WaitTask"))
	virtual FString WaitTask(TScriptInterface<IAsyncForInterfaces_Base> AsyncForTask) = 0;
};

//直接接入的--------------------------------------------------------------------------------------

UINTERFACE(MinimalAPI,NotBlueprintable,BlueprintType)
class UAsyncForInterfaces_Wait : public UAsyncForInterfaces_General
{
	GENERATED_BODY()
};

class IAsyncForInterfaces_Wait : public IAsyncForInterfaces_General
{
	GENERATED_BODY()
public:
	/**
	* Immediately pauses the current loop.
	* 
	* @return Have to call "run" when handled,otherwise loop stop.
	*/
	UFUNCTION(BlueprintCallable, Category = "AsyncTaskHelper|Interfaces", meta = (CompactNodeTitle = "Wait"))
	virtual TScriptInterface<IAsyncForInterfaces_Run> Wait() = 0;
};

/*只能由前者调出*/
UINTERFACE(MinimalAPI,NotBlueprintable,BlueprintType)
class UAsyncForInterfaces_Run : public UInterface
{
	GENERATED_BODY()
};

class IAsyncForInterfaces_Run
{
	GENERATED_BODY()
public:
	/**
	* resumes the current loop.
	*/
	UFUNCTION(BlueprintCallable, Category = "AsyncTaskHelper|Interfaces", meta = (CompactNodeTitle = "Run"))
	virtual void Run() = 0;
};


UINTERFACE(MinimalAPI,NotBlueprintable,BlueprintType)
class UAsyncForInterfaces_WaitTime : public UAsyncForInterfaces_General
{
	GENERATED_BODY()
};

class IAsyncForInterfaces_WaitTime : public IAsyncForInterfaces_General
{
	GENERATED_BODY()
public:
	/**
	* Immediately pauses the current loop and resumes after time over
	* 
	* @param Time	auto run when time over
	*/
	UFUNCTION(BlueprintCallable, Category = "AsyncTaskHelper|Interfaces", meta = (CompactNodeTitle = "WaitTime"))
	virtual void WaitTime(float Time) = 0;
};


UINTERFACE(MinimalAPI,NotBlueprintable,BlueprintType)
class UAsyncForInterfaces_Timer : public UAsyncForInterfaces_General
{
	GENERATED_BODY()
};

class IAsyncForInterfaces_Timer : public IAsyncForInterfaces_General
{
	GENERATED_BODY()
public:
	/**
	* Immediately pauses the current loop and resumes when unpause
	* 
	*/
	UFUNCTION(BlueprintCallable, Category = "AsyncTaskHelper|Interfaces", meta = (CompactNodeTitle = "Pause"))
	virtual void Pause() = 0;
	/**
	* Resumes the current loop
	* 
	*/
	UFUNCTION(BlueprintCallable, Category = "AsyncTaskHelper|Interfaces", meta = (CompactNodeTitle = "Unpause"))
	virtual void Unpause() = 0;
};


UINTERFACE(MinimalAPI,NotBlueprintable,BlueprintType)
class UAsyncForInterfaces_Next : public UAsyncForInterfaces_General
{
	GENERATED_BODY()
};

class IAsyncForInterfaces_Next : public IAsyncForInterfaces_General
{
	GENERATED_BODY()
public:
	/**
	* Make into next loopbody
	* 
	*/
	UFUNCTION(BlueprintCallable, Category = "AsyncTaskHelper|Interfaces", meta = (CompactNodeTitle = "Next"))
	virtual void Next() = 0;
	
};