﻿// Copyright lurongjiu 2026 All Rights Reserved.
#pragma once

#include "CoreMinimal.h"
#include "Engine/Engine.h"
#include "Containers/Queue.h"
#include "Engine/World.h"
#include "TimerManager.h"  
#include "UObject/ObjectPtr.h"
#include "UObject/Object.h"
#include "AsyncForCounter.h"
#include "AsyncForInterfaces.h"
#include "GenericTypeHelperLibrary.h"
#include "Kismet/BlueprintAsyncActionBase.h"
#include "AsyncForEachLoop.generated.h"

class UAsyncTaskQueueAction;
//class FAsyncForCounter;
UENUM(/*BlueprintType*/)
enum class EForEachMode : uint8
{
	WaitRun UMETA(DisplayName="WaitRun"),
	WaitTime UMETA(DisplayName="WaitTime"),
	TimerLoop UMETA(DisplayName="TimerLoop"),
	Next UMETA(DisplayName="Next"),
};


namespace FailReasons
{
	static FString SelfFinished = TEXT("self is finished");
	static FString Persistent = TEXT("sub task is persistent");
	static FString SubFinished = TEXT("sub task is finished");
	static FString InTask = TEXT("sub task is a in a queue already");
	static FString Activated = TEXT("sub task is activated already");
	static FString SubAutoActivate = TEXT("sub task will auto activate");
	static FString SelfAutoActivate = TEXT("self will auto activate");
}

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FAsyncCompleted);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FAsyncDelayAction_PossessVar, FGenericVarContainer, Var);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FAsyncLoopBody_PureCount, int32, Index);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FAsyncLoopBody_GenericVarContainer, FGenericVarContainer, Item, int32, Index);

UCLASS()
class UAsyncForEachAsyncAction : public UBlueprintAsyncActionBase, public IAsyncForInterfaces_WaitTime, public IAsyncForInterfaces_Wait, public IAsyncForInterfaces_Run, public IAsyncForInterfaces_Timer, public IAsyncForInterfaces_Next
{
	GENERATED_BODY()

public:

	UPROPERTY(BlueprintAssignable)
	FAsyncCompleted Completed;
	
	virtual void Activate() override;

	virtual int32 GetLastIndex(){return 0;}

	virtual void OnLoopBody(int32 Index){}

	virtual TScriptInterface<IAsyncForInterfaces_Run> Wait() override;
	virtual void Run() override;
	virtual void WaitTime(float Time) override;
	virtual void Break() override;
	virtual void Pause() override;
	virtual void Unpause() override;
	virtual void Next() override;
	virtual FString WaitTask(TScriptInterface<IAsyncForInterfaces_Base> AsyncForTask) override;
	virtual bool AddToTaskCheck(FString& FailReason) override;
	virtual FString Start() override;
	virtual FAsyncCompleted& GetComplete() override{return Completed;}
	virtual bool IsFinished() override{return Finished;}
	virtual bool IsPersistent() override{return false;}
	virtual void OnStart() override;
protected:
	
	FTimerManager& GetTimerManager();
	bool Reverse = false;
	
	TUniquePtr<FAsyncForCounter> Counter = nullptr;
	EForEachMode ForEachMode;

	FTimerHandle TimerHandle;
	float TimerInterval;
	
	bool AutoActivate = true;
	bool Activated = false;
	bool InTask = false;
	bool Finished = false;
	
	UPROPERTY()
	TObjectPtr<UObject> WorldContextObject;
		
	UFUNCTION()
	void Start_Internal();
};

//禁止自动生成异步节点
UCLASS(meta=(HasDedicatedAsyncNode))
class ASYNCFOR_API UAsyncForLoop_GenericVarContainer : public UAsyncForEachAsyncAction
{
	GENERATED_BODY()
	
public:
	
	UPROPERTY(BlueprintAssignable)
	FAsyncLoopBody_GenericVarContainer LoopBody;

	//没办法隐藏这些函数,而且Category不设置就会默认按类名|函数名
	UFUNCTION(BlueprintCallable, meta=(BlueprintInternalUseOnly="true",WorldContext = "WorldContext", DefaultToSelf = "WorldContext"))
	static UAsyncForLoop_GenericVarContainer* AsyncForEach_GenericVarContainer_WaitTime(UObject* WorldContext, TScriptInterface<IAsyncForInterfaces_WaitTime>& WaitTimeInterface, const TArray<FGenericVarContainer>& Array, const bool Reverse = false, const bool AutoStart = true);
	
	UFUNCTION(BlueprintCallable, meta=(BlueprintInternalUseOnly="true",WorldContext = "WorldContext", DefaultToSelf = "WorldContext"))
	static UAsyncForLoop_GenericVarContainer* AsyncForEach_GenericVarContainer_WaitRun(UObject* WorldContext, TScriptInterface<IAsyncForInterfaces_Wait>& WaitRunInterface, const TArray<FGenericVarContainer>& Array, const bool Reverse = false, const bool AutoStart = true);

	UFUNCTION(BlueprintCallable, meta=(BlueprintInternalUseOnly="true",WorldContext = "WorldContext", DefaultToSelf = "WorldContext"))
	static UAsyncForLoop_GenericVarContainer* AsyncForEach_GenericVarContainer_TimerLoop(UObject* WorldContext, TScriptInterface<IAsyncForInterfaces_Timer>& TimerInterface, const TArray<FGenericVarContainer>&Array, const bool Reverse = false, const float Time = 0.0f, const bool AutoStart = true);

	UFUNCTION(BlueprintCallable, meta=(BlueprintInternalUseOnly="true",WorldContext = "WorldContext", DefaultToSelf = "WorldContext"))
	static UAsyncForLoop_GenericVarContainer* AsyncForEach_GenericVarContainer_Next(UObject* WorldContext, TScriptInterface<IAsyncForInterfaces_Next>& NextInterface, const TArray<FGenericVarContainer>&Array, const bool Reverse = false, const bool AutoStart = true);
	
	virtual int32 GetLastIndex() override;
	virtual void OnLoopBody(int32 Index) override;


private:

	TArray<FGenericVarContainer> Array;

	static UAsyncForLoop_GenericVarContainer* CreateAsyncForLoopObject(UObject* InWorldContext, const EForEachMode InForEachMode, const TArray<FGenericVarContainer>& InArray, const bool InReverse, const bool AutoStart);
	
};

UCLASS(meta=(HasDedicatedAsyncNode))
class ASYNCFOR_API UAsyncForLoop_PureCount : public UAsyncForEachAsyncAction
{
	GENERATED_BODY()
	
public:

	//呼叫对应的引脚
	UPROPERTY(BlueprintAssignable)
	FAsyncLoopBody_PureCount LoopBody;
	
	UFUNCTION(BlueprintCallable, meta=(BlueprintInternalUseOnly="true",WorldContext = "WorldContext", DefaultToSelf = "WorldContext"))
	static UAsyncForLoop_PureCount* AsyncForEach_PureCount_WaitTime(UObject* WorldContext,TScriptInterface<IAsyncForInterfaces_WaitTime>& WaitTimeInterface, const int32 LastIndex, const bool Reverse = false, const bool AutoStart = true);
	
	UFUNCTION(BlueprintCallable, meta=(BlueprintInternalUseOnly="true",WorldContext = "WorldContext", DefaultToSelf = "WorldContext"))
	static UAsyncForLoop_PureCount* AsyncForEach_PureCount_WaitRun(UObject* WorldContext,TScriptInterface<IAsyncForInterfaces_Wait>& WaitRunInterface, const int32 LastIndex, const bool Reverse = false, const bool AutoStart = true);

	UFUNCTION(BlueprintCallable, meta=(BlueprintInternalUseOnly="true",WorldContext = "WorldContext", DefaultToSelf = "WorldContext"))
	static UAsyncForLoop_PureCount* AsyncForEach_PureCount_TimerLoop(UObject* WorldContext,TScriptInterface<IAsyncForInterfaces_Timer>& TimerInterface, const int32 LastIndex, const bool Reverse = false, const float Time = 0.0f, const bool AutoStart = true);

	UFUNCTION(BlueprintCallable, meta=(BlueprintInternalUseOnly="true",WorldContext = "WorldContext", DefaultToSelf = "WorldContext"))
	static UAsyncForLoop_PureCount* AsyncForEach_PureCount_Next(UObject* WorldContext,TScriptInterface<IAsyncForInterfaces_Next>& NextInterface, const int32 LastIndex, const bool Reverse = false, const bool AutoStart = true);
	
	virtual int32 GetLastIndex() override;
	virtual void OnLoopBody(int32 Index) override;
	
private:

	int32 LastIndex;

	static UAsyncForLoop_PureCount* CreateAsyncForLoopObject(UObject* InWorldContext, const EForEachMode InForEachMode, const int32& LastIndex, const bool InReverse, const bool AutoStart);
	
};

UCLASS(/*meta=(HideThen)*/)
class UAsyncTaskQueueAction : public UBlueprintAsyncActionBase, public IAsyncForInterfaces_TaskQueue
{
	GENERATED_BODY()
	
public:

	UPROPERTY(BlueprintAssignable)
	FAsyncCompleted Completed;
		
	/**
	* Create a queue task
	*
	* @param TaskInterface	Queue task manager handle
	* @param AutoStart	Auto start on first task add
	* @param Persistent	if false, task manager will auto break when queue empty
	*
	*/
	UFUNCTION(BlueprintCallable, Category = "AsyncTaskHelper|Utilities", meta=(BlueprintInternalUseOnly="true",WorldContext = "WorldContext", DefaultToSelf = "WorldContext"))
	static UAsyncTaskQueueAction* MakeAsyncTaskQueue(UObject* WorldContext, TScriptInterface<IAsyncForInterfaces_TaskQueue>& TaskInterface, const bool AutoStart = true, const bool Persistent = true);
	
	virtual void Break() override;
	virtual FString AddTask(TScriptInterface<IAsyncForInterfaces_Base> NewTask) override;
	virtual bool AddToTaskCheck(FString& FailReason) override;
	virtual FString Start() override;
	virtual FAsyncCompleted& GetComplete() override{return Completed;}
	virtual bool IsFinished() override{return Finished;}
	virtual bool IsPersistent() override{return Persistent;}
	virtual void OnStart() override;
private:
	//TQueue<TScriptInterface<IAsyncForInterfaces_Base>> TaskQueue;
	//兼容上下版本,5.5及以前必须有EQueueMode::Spsc
	TQueue<TScriptInterface<IAsyncForInterfaces_Base>, EQueueMode::Spsc> TaskQueue;

	bool Persistent = false;
	bool Waitting = true;
	bool AutoActivate = true;
	bool Activated = false;
	bool InTask = false;
	bool Finished = false;
	
	UPROPERTY()
	TObjectPtr<UObject> WorldContextObject;
	//必须宏标记才能adddynamic
	UFUNCTION()
	void NextTask();
	
};

UCLASS(meta=(HideThen))
class UAsyncDelayAction : public UBlueprintAsyncActionBase
{
	GENERATED_BODY()

public:
	
	UPROPERTY(BlueprintAssignable)
	FAsyncDelayAction_PossessVar OnFinish;
		
	/**
	* Create a delay task and possess a variable
	*
	* @param Var	Possess a variable and output on called
	* @param Time	Delay time
	*
	*/
	UFUNCTION(BlueprintCallable, Category = "AsyncTaskHelper|Utilities", meta=(BlueprintInternalUseOnly="true",WorldContext = "WorldContext", DefaultToSelf = "WorldContext"))
	static UAsyncDelayAction* DelayPossessVar(UObject* WorldContext, const FGenericVarContainer Var, const float Time = 0.2);

	virtual void Activate() override;

private:
	FGenericVarContainer VarContainer;
	UPROPERTY()
	TObjectPtr<UObject> WorldContextObject;
	float Time = 0.0f;
};

UCLASS(meta=(HasDedicatedAsyncNode))
class ASYNCFOR_API UAsyncSimpleSingleTaskAction : public UBlueprintAsyncActionBase, public IAsyncForInterfaces_Base
{
	GENERATED_BODY()

public:
	
	UPROPERTY(BlueprintAssignable)
	FAsyncDelayAction_PossessVar OnCalled;

	//不作为输出引脚到蓝图
	//UPROPERTY(BlueprintAssignable)
	FAsyncCompleted OnCompleted;
	
	/**
	* Create a one-time task that can be added to a queue. or be used without queue and started manually at any time.
	*
	* @param SimpleTaskInterfaces	Handle to add task or control manually
	* @param Var					Possess a variable and output on called
	* @param AutoFinishTime			Auto finish on delay time on called, if < 0,have to call "break" to end task;
	*
	*/
	UFUNCTION(BlueprintCallable, meta=(BlueprintInternalUseOnly="true",WorldContext = "WorldContext", DefaultToSelf = "WorldContext"))
	static UAsyncSimpleSingleTaskAction* SimpleSingleTimeTask(UObject* WorldContext, TScriptInterface<IAsyncForInterfaces_Base>& SimpleTaskInterfaces, const FGenericVarContainer Var, const float AutoFinishTime = -1.f);
	
	virtual FAsyncCompleted& GetComplete() override{return OnCompleted;}
	virtual bool AddToTaskCheck(FString& FailReason) override;
	virtual FString Start() override;
	virtual void Break() override;
	virtual bool IsFinished() override{return Finished;}
	virtual bool IsPersistent() override{return false;}
	virtual void OnStart() override;
private:
	FGenericVarContainer VarContainer;
	bool InTask = false;
	bool Activated = false;
	bool Finished = false;
	float Time = 0.0f;
	UPROPERTY()
	TObjectPtr<UObject> WorldContextObject;
};

UCLASS(meta=(HasDedicatedAsyncNode))
class ASYNCFOR_API UAsyncSimpleMultipleTaskAction : public UBlueprintAsyncActionBase, public IAsyncForInterfaces_Base
{
	GENERATED_BODY()

public:
	
	UPROPERTY(BlueprintAssignable)
	FAsyncDelayAction_PossessVar OnCalled;

	//不作为输出引脚到蓝图
	FAsyncCompleted OnCompleted;
	
	/**
	* Create a multi-times task. can not to add to task queue, can call multi-times start until call break;
	*
	* @param SimpleTaskInterfaces	Handle to add task or control manually
	* @param Var					Possess a variable and output on called
	*
	*/
	UFUNCTION(BlueprintCallable, meta=(BlueprintInternalUseOnly="true",WorldContext = "WorldContext", DefaultToSelf = "WorldContext"))
	static UAsyncSimpleMultipleTaskAction* SimpleMultipleTimesTask(UObject* WorldContext, TScriptInterface<IAsyncForInterfaces_Base>& SimpleTaskInterfaces, const FGenericVarContainer Var);

	
	virtual FAsyncCompleted& GetComplete() override{return OnCompleted;}
	virtual bool AddToTaskCheck(FString& FailReason) override;
	virtual FString Start() override;
	virtual void Break() override;
	virtual bool IsFinished() override{return Finished;}
	virtual bool IsPersistent() override{return true;}
	virtual void OnStart() override{};
private:
	FGenericVarContainer VarContainer;
	bool Finished = false;
	UPROPERTY()
	TObjectPtr<UObject> WorldContextObject;
};