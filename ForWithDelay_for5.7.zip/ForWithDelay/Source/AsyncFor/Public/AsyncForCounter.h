﻿// Copyright lurongjiu 2026 All Rights Reserved.
#pragma once

#include "CoreMinimal.h"
DECLARE_MULTICAST_DELEGATE_OneParam(FOnLoopBody,int32)
DECLARE_MULTICAST_DELEGATE(FOnComplete)


class FAsyncForCounter
{
public:
	FAsyncForCounter(const bool bReverse,const int32 LastIndex):
	Index(0),
	LastIndex(LastIndex),
	IsRunning(false),
	IsComplete(false),
	Reverse(bReverse),
	ShouldFinished(false),
	PendingNext(false),
	PendingRun(false),
	OnLoopBody(false)
	{}
	
	~FAsyncForCounter(){}

	void Run();
	void Wait();
	void Next();
	void Break();
	
	FOnLoopBody LoopBody;
	FOnComplete Complete;
	
	//ECounterState CounterState;
	
private:

	//当前执行到的index
	int32 Index;
	//最大index
	int32 LastIndex;
	//自动遍历
	bool IsRunning;
	//是否已结束
	bool IsComplete;
	//逆序输出,创建时初始化
	bool Reverse;
	//是否应该在下次结束,loop内判断
	bool ShouldFinished;
	//在遍历体boardcast时,调用next不应立即执行,而应该等程序流到++index之后才执行,也可能延迟调用(异步),那么程序已经++index过了,可以之间执行
	bool PendingNext;
	//在遍历体boardcast时,调用run不应立即执行,而应该等程序流到++index之后才执行,也可能延迟调用(异步),那么程序已经++index过了,可以之间执行
	bool PendingRun;
	//是否还未++index
	bool OnLoopBody;
	
	void OnLoop();
};
