﻿// Copyright lurongjiu 2026 All Rights Reserved.
#include "AsyncForCounter.h"

#include "AsyncFor.h"
#include "GenericTypeHelper.h"


void FAsyncForCounter::Run()
{
	if(IsRunning) return;
	IsRunning = true;
	if(OnLoopBody)
	{
		PendingRun = true;
		return;
	}
	
	while (IsRunning)
	{
		if (ShouldFinished)
		{
			Break();
			break;
		}
		OnLoop();
	}
}

void FAsyncForCounter::Wait()
{
	IsRunning = false;
	//PendingRun之后wait无权再次阻止,PendingRun只是为了阻止无限循环,不能用在这里
	//PendingRun = false;
}

void FAsyncForCounter::Next()
{
	if (ShouldFinished)
	{
		Break();
		return;
	}
	
	if (!IsRunning)
	{
		if(OnLoopBody)
		{
			PendingNext = true;
			return;
		}
		OnLoop();
	}
}

void FAsyncForCounter::Break()
{
	if (!IsComplete)
	{
		IsComplete = true;
		IsRunning = false;
		Complete.Broadcast();
		LoopBody.Clear();
		Complete.Clear();
	}
}

void FAsyncForCounter::OnLoop()
{
	ShouldFinished = Index >= LastIndex;
	OnLoopBody = true;
	if(!Reverse)
	{
		LoopBody.Broadcast(Index);
	}
	else
	{
		LoopBody.Broadcast(LastIndex - Index);
	}

	++Index;
	OnLoopBody = false;
	
	if(PendingNext)
	{
		PendingNext = false;
		Next();
	}
	else if(PendingRun)
	{
		PendingRun = false;
		Run();
	}
}
