﻿// Copyright lurongjiu 2026 All Rights Reserved.
#include "AsyncForEachLoop.h"

//#include "AssetPrivatizeModel.h"
#include "TimerManager.h"
#include "Engine/World.h"
#include "AsyncForCounter.h"
#include "AsyncFor.h"
#include "GenericTypeHelper.h"
#include "Kismet/KismetSystemLibrary.h"


/*----------------------------------------------------------parent----------------------------------------------------------------------*/
void UAsyncForEachAsyncAction::Activate()
{
	Super::Activate();
	RegisterWithGameInstance(WorldContextObject);
	if(!AutoActivate) return;
	if(Activated) return;
	OnStart();
}

TScriptInterface<IAsyncForInterfaces_Run> UAsyncForEachAsyncAction::Wait()
{
	if(Finished) return this;
	Counter->Wait();
	return this;
}

void UAsyncForEachAsyncAction::Run()
{
	if(Finished) return;
	Counter->Run();
}

void UAsyncForEachAsyncAction::WaitTime(float Time)
{
	if(Finished) return;
	if(Time > 0)
	{
		Counter->Wait();
	
		FTimerManager& TimerManager = GetTimerManager();
		TimerManager.SetTimer(TimerHandle,
			FTimerDelegate::CreateLambda([this]()
			{
				Counter->Run();
			}),
			Time,
			false);
	}
}

void UAsyncForEachAsyncAction::Break()
{
	if(Finished) return;
	Finished = true;
	Counter->Break();
	SetReadyToDestroy();
}

FString UAsyncForEachAsyncAction::Start()
{
	if(Activated)
	{
		return FailReasons::Activated;
	}
	if(Finished)
	{
		return FailReasons::SelfFinished;
	}
	if(InTask)
	{
		return FailReasons::InTask;
	}
	
	OnStart();
	return FString();
}

void UAsyncForEachAsyncAction::Pause()
{
	if(Finished) return;
	if(TimerInterval>0)
	{
		//pause和unpause不好用,直接清除+新建
		//GetTimerManager().PauseTimer(TimerHandle);
		GetTimerManager().ClearTimer(TimerHandle);
	}
	else
	{
		Wait();
	}
}

void UAsyncForEachAsyncAction::Unpause()
{
	if(Finished) return;
	if(TimerInterval>0)
	{
		//pause和unpause不好用,直接清除+新建
		//GetTimerManager().UnPauseTimer(TimerHandle);
		FTimerManager& TimerManager = GetTimerManager();
		TimerManager.SetTimer(TimerHandle,FTimerDelegate::CreateLambda([this]()
		{
			Counter->Next();
		
		}),TimerInterval,true);
	}
	else
	{
		Run();
	}
	
}

void UAsyncForEachAsyncAction::Next()
{
	if(Finished) return;
	Counter->Next();
}

FString UAsyncForEachAsyncAction::WaitTask(TScriptInterface<IAsyncForInterfaces_Base> AsyncForTask)
{
	
	if(AsyncForTask->IsPersistent())
	{
		return FailReasons::Persistent;
	}
	if(Finished)
	{
		return FailReasons::SelfFinished;
	}
	if(AsyncForTask->IsFinished())
	{
		if(Activated && ForEachMode == EForEachMode::Next)
		{
			Next();
			return FString();
		}
		return FailReasons::SubFinished;
	}
	if(AutoActivate && !Activated)
	{
		return FailReasons::SelfAutoActivate;
	}
	
	if(Activated)
	{
		if(ForEachMode == EForEachMode::WaitRun || ForEachMode == EForEachMode::WaitTime)
		{
			Counter->Wait();
			AsyncForTask->GetComplete().AddDynamic(this, &UAsyncForEachAsyncAction::Run);
		}
		else if(ForEachMode == EForEachMode::TimerLoop)
		{
			if(TimerInterval>0)
			{
				GetTimerManager().PauseTimer(TimerHandle);
				AsyncForTask->GetComplete().AddDynamic(this, &UAsyncForEachAsyncAction::Unpause);
			}
			else
			{
				Counter->Wait();
				AsyncForTask->GetComplete().AddDynamic(this, &UAsyncForEachAsyncAction::Run);
			}
		}
		else if(ForEachMode == EForEachMode::Next)
		{
			AsyncForTask->GetComplete().AddDynamic(this, &UAsyncForEachAsyncAction::Next);
		}
	}
	/*else if(AutoActivate)
	{
		//如果原本设置是自带激活的,无法阻止
		AutoActivate = false;
		//如果还未开始,应该调用低优先级的start,检查是否可以开始.而不是onstart,
		AsyncForTask->GetComplete().AddDynamic(this, &UAsyncForEachAsyncAction::Start_Internal);
	}*/
	return FString();
}

bool UAsyncForEachAsyncAction::AddToTaskCheck(FString& FailReason)
{
	if(InTask)
	{
		FailReason = FailReasons::InTask;
		return false;
	}
	if(Activated)
	{
		FailReason = FailReasons::Activated;
		return false;
	}
	if(AutoActivate)
	{
		FailReason = FailReasons::SubAutoActivate;
		return false;
	}
	if(Finished)
	{
		FailReason = FailReasons::SubFinished;
		return false;
	}
	
	InTask = true;
	//如果所属的任务结束,自己也结束
	//如果自己先结束但不解绑,对方广播时将引起崩溃, 不绑定,对方结束时遍历通知break
	//Task->GetComplete().AddDynamic(this, &UAsyncForEachAsyncAction::Break);
	
	return true;
}


void UAsyncForEachAsyncAction::OnStart()
{
	Activated = true;
	Counter = MakeUnique<FAsyncForCounter>(Reverse,GetLastIndex());

	//bind delegate
	Counter->LoopBody.AddLambda([this](const int32 Index)
	{
		OnLoopBody(Index);
	});
	
	Counter->Complete.AddLambda([this]()
	{
		Completed.Broadcast();
	});

	//initial
	if(ForEachMode == EForEachMode::WaitRun || ForEachMode == EForEachMode::WaitTime)
	{
		Counter->Run();
	}
	else if(ForEachMode == EForEachMode::TimerLoop)
	{
		if(TimerInterval > 0)
		{
			//直接设置计数器,首个也会延迟,所以直接调用一次,第二个才延迟
			//Counter->Next();
			FTimerManager& TimerManager = GetTimerManager();
			TimerManager.SetTimer(TimerHandle,FTimerDelegate::CreateLambda([this]()
			{
				Counter->Next();
		
			}),TimerInterval,true,0.f);
		}
		else
		{
			//如果设计为timer loop但时间为0,按run
			Counter->Run();
		}
		
	}
	else if(ForEachMode == EForEachMode::Next)
	{
		Counter->Next();
	}
}

FTimerManager& UAsyncForEachAsyncAction::GetTimerManager()
{
	return GEngine->GetWorldFromContextObject(WorldContextObject,EGetWorldErrorMode::LogAndReturnNull)->GetTimerManager();
}

void UAsyncForEachAsyncAction::Start_Internal()
{
	Start();
}
/*----------------------------------------------------------parent----------------------------------------------------------------------*/

/*----------------------------------------------------------array----------------------------------------------------------------------*/


UAsyncForLoop_GenericVarContainer* UAsyncForLoop_GenericVarContainer::AsyncForEach_GenericVarContainer_WaitTime(UObject* WorldContext, TScriptInterface<IAsyncForInterfaces_WaitTime>& WaitTimeInterface,const TArray<FGenericVarContainer>& Array, const bool Reverse, const bool AutoStart)
{
	UAsyncForLoop_GenericVarContainer* Node = CreateAsyncForLoopObject(WorldContext,EForEachMode::WaitTime,Array, Reverse,AutoStart);
	
	WaitTimeInterface = Node;
	
	return Node;
}

UAsyncForLoop_GenericVarContainer* UAsyncForLoop_GenericVarContainer::AsyncForEach_GenericVarContainer_WaitRun(UObject* WorldContext, TScriptInterface<IAsyncForInterfaces_Wait>& WaitRunInterface,const TArray<FGenericVarContainer>& Array, const bool Reverse, const bool AutoStart)
{
	UAsyncForLoop_GenericVarContainer* Node = CreateAsyncForLoopObject(WorldContext,EForEachMode::WaitRun,Array, Reverse,AutoStart);
	
	WaitRunInterface = Node;
	
	return Node;
}

UAsyncForLoop_GenericVarContainer* UAsyncForLoop_GenericVarContainer::AsyncForEach_GenericVarContainer_TimerLoop(UObject* WorldContext, TScriptInterface<IAsyncForInterfaces_Timer>& TimerInterface,const TArray<FGenericVarContainer>& Array, const bool Reverse, const float Time, const bool AutoStart)
{
	UAsyncForLoop_GenericVarContainer* Node = CreateAsyncForLoopObject(WorldContext,EForEachMode::TimerLoop,Array, Reverse,AutoStart);
	
	TimerInterface = Node;
	Node->TimerInterval = Time;
	
	return Node;
}

UAsyncForLoop_GenericVarContainer* UAsyncForLoop_GenericVarContainer::AsyncForEach_GenericVarContainer_Next(UObject* WorldContext, TScriptInterface<IAsyncForInterfaces_Next>& NextInterface,const TArray<FGenericVarContainer>& Array, const bool Reverse, const bool AutoStart)
{
	UAsyncForLoop_GenericVarContainer* Node = CreateAsyncForLoopObject(WorldContext,EForEachMode::Next,Array, Reverse,AutoStart);
	
	NextInterface = Node;
	
	return Node;
}

int32 UAsyncForLoop_GenericVarContainer::GetLastIndex()
{
	return Array.Num() - 1;
}

void UAsyncForLoop_GenericVarContainer::OnLoopBody(int32 Index)
{
	if(Finished) return;
	Super::OnLoopBody(Index);
	LoopBody.Broadcast(Array[Index],Index);
}

UAsyncForLoop_GenericVarContainer* UAsyncForLoop_GenericVarContainer::CreateAsyncForLoopObject(UObject* InWorldContext,const EForEachMode InForEachMode, const TArray<FGenericVarContainer>& InArray, const bool InReverse, const bool AutoStart)
{
	UAsyncForLoop_GenericVarContainer* Node = NewObject<UAsyncForLoop_GenericVarContainer>();

	Node->WorldContextObject = InWorldContext;
	Node->Array = InArray;
	Node->Reverse = InReverse;
	Node->ForEachMode = InForEachMode;
	Node->AutoActivate = AutoStart;
	
	return Node;
}

/*----------------------------------------------------------PureCount----------------------------------------------------------------------*/
UAsyncForLoop_PureCount* UAsyncForLoop_PureCount::AsyncForEach_PureCount_WaitTime(UObject* WorldContext,TScriptInterface<IAsyncForInterfaces_WaitTime>& WaitTimeInterface, const int32 LastIndex, const bool Reverse, const bool AutoStart)
{
	UAsyncForLoop_PureCount* Node = CreateAsyncForLoopObject(WorldContext,EForEachMode::WaitTime,LastIndex, Reverse,AutoStart);
	
	WaitTimeInterface = Node;
	
	return Node;
}

UAsyncForLoop_PureCount* UAsyncForLoop_PureCount::AsyncForEach_PureCount_WaitRun(UObject* WorldContext,TScriptInterface<IAsyncForInterfaces_Wait>& WaitRunInterface, const int32 LastIndex, const bool Reverse, const bool AutoStart)
{
	UAsyncForLoop_PureCount* Node = CreateAsyncForLoopObject(WorldContext,EForEachMode::WaitRun,LastIndex, Reverse,AutoStart);
	
	WaitRunInterface = Node;
	
	return Node;
}

UAsyncForLoop_PureCount* UAsyncForLoop_PureCount::AsyncForEach_PureCount_TimerLoop(UObject* WorldContext,TScriptInterface<IAsyncForInterfaces_Timer>& TimerInterface, const int32 LastIndex, const bool Reverse,const float Time, const bool AutoStart)
{
	UAsyncForLoop_PureCount* Node = CreateAsyncForLoopObject(WorldContext,EForEachMode::TimerLoop,LastIndex, Reverse,AutoStart);
	
	TimerInterface = Node;
	Node->TimerInterval = Time;
	
	return Node;
}

UAsyncForLoop_PureCount* UAsyncForLoop_PureCount::AsyncForEach_PureCount_Next(UObject* WorldContext,TScriptInterface<IAsyncForInterfaces_Next>& NextInterface, const int32 LastIndex, const bool Reverse, const bool AutoStart)
{
	UAsyncForLoop_PureCount* Node = CreateAsyncForLoopObject(WorldContext,EForEachMode::Next,LastIndex, Reverse,AutoStart);
	
	NextInterface = Node;
	
	return Node;
}

int32 UAsyncForLoop_PureCount::GetLastIndex()
{
	return LastIndex;
}

void UAsyncForLoop_PureCount::OnLoopBody(int32 Index)
{
	if(Finished) return;
	Super::OnLoopBody(Index);
	LoopBody.Broadcast(Index);
}

UAsyncForLoop_PureCount* UAsyncForLoop_PureCount::CreateAsyncForLoopObject(UObject* InWorldContext,const EForEachMode InForEachMode, const int32& LastIndex, const bool InReverse, const bool AutoStart)
{
	UAsyncForLoop_PureCount* Node = NewObject<UAsyncForLoop_PureCount>();

	Node->WorldContextObject = InWorldContext;
	Node->LastIndex = LastIndex;
	Node->Reverse = InReverse;
	Node->ForEachMode = InForEachMode;
	Node->AutoActivate = AutoStart;
	
	return Node;
}
//-------------------------------------------------------------AsyncTaskQueue----------------------------------------------------
UAsyncTaskQueueAction* UAsyncTaskQueueAction::MakeAsyncTaskQueue(UObject* WorldContext, TScriptInterface<IAsyncForInterfaces_TaskQueue>& TaskInterface, const bool AutoStart, const bool Persistent)
{
	UAsyncTaskQueueAction* Node = NewObject<UAsyncTaskQueueAction>();
	
	Node->WorldContextObject = WorldContext;
	Node->RegisterWithGameInstance(WorldContext);
	Node->AutoActivate = AutoStart;
	Node->Persistent = Persistent;
	
	TaskInterface = Node;
	
	return Node;
}

void UAsyncTaskQueueAction::Break()
{
	if (Finished) return;

	//empty and break sub tasks
	TScriptInterface<IAsyncForInterfaces_Base> Task;
	while (TaskQueue.Dequeue(Task))
	{
		Task->Break();
	}

	Completed.Broadcast();
	Completed.Clear();
	Finished = true;
	SetReadyToDestroy();
}

FString UAsyncTaskQueueAction::AddTask(TScriptInterface<IAsyncForInterfaces_Base> NewTask)
{
	if(Finished)
	{
		return FailReasons::SelfFinished;
	}
	
	FString FailReason = FString();
	if(NewTask->AddToTaskCheck(FailReason))
	{
		if(TaskQueue.Enqueue(NewTask))
		{
			if(Activated && Waitting)
			{
				NextTask();
			}
			else if(AutoActivate && !Activated)
			{
				OnStart();
			}
		}
		FailReason = TEXT("Failed to enqueue");
	}
	return FailReason;
}

bool UAsyncTaskQueueAction::AddToTaskCheck(FString& FailReason)
{
	if(InTask)
	{
		FailReason = FailReasons::InTask;
		return false;
	}
	if(Activated)
	{
		FailReason = FailReasons::Activated;
		return false;
	}
	if(AutoActivate)
	{
		FailReason = FailReasons::SubAutoActivate;
		return false;
	}
	if(Finished)
	{
		FailReason = FailReasons::SubFinished;
		return false;
	}
	InTask = true;

	return true;
}

FString UAsyncTaskQueueAction::Start()
{
	if(Activated)
	{
		return FailReasons::Activated;
	}
	if(Finished)
	{
		return FailReasons::SelfFinished;
	}
	if(InTask)
	{
		return FailReasons::InTask;
	}
	
	OnStart();
	return FString();
}

void UAsyncTaskQueueAction::OnStart()
{
	Activated = true;
	NextTask();
}

void UAsyncTaskQueueAction::NextTask()
{
	if(Finished) return;
	
	TScriptInterface<IAsyncForInterfaces_Base> Task;
	
	if(TaskQueue.Dequeue(Task))
	{
		//break优先级更高,如果任务被提前break了,跳过,也可能来自错误操作
		if(!Task->IsFinished())
		{
			//对管理的任务有高优先级,直接调用onstart,其余调用start并检查是否允许
			Waitting = false;
			Task->OnStart();
			Task->GetComplete().AddDynamic(this, &UAsyncTaskQueueAction::NextTask);
			return;
		}
		NextTask();
	}

	else if(!Persistent)
	{
		Break();
		return;
	}
	//如果前边没有执行,就是在等待了
	Waitting = true;
}

///------------------------------------------------delay

UAsyncDelayAction* UAsyncDelayAction::DelayPossessVar(UObject* WorldContext, const FGenericVarContainer Var, const float Time)
{
	UAsyncDelayAction* Node = NewObject<UAsyncDelayAction>();

	Node->WorldContextObject = WorldContext;
	Node->Time = Time;
	Node->VarContainer = Var;
	
	return Node;
}

void UAsyncDelayAction::Activate()
{
	Super::Activate();
	if(Time > 0)
	{
		FTimerManager& TimerManager = GEngine->GetWorldFromContextObject(WorldContextObject,EGetWorldErrorMode::LogAndReturnNull)->GetTimerManager();
		FTimerHandle Handle;
		TimerManager.SetTimer(Handle,
			FTimerDelegate::CreateLambda([this]()
			{
				OnFinish.Broadcast(VarContainer);
				OnFinish.Clear();
				SetReadyToDestroy();
			}),
			Time,
			false);
	}
	else
	{
		OnFinish.Broadcast(VarContainer);
		OnFinish.Clear();
		SetReadyToDestroy();
	}
}


UAsyncSimpleSingleTaskAction* UAsyncSimpleSingleTaskAction::SimpleSingleTimeTask(UObject* WorldContext,	TScriptInterface<IAsyncForInterfaces_Base>& SimpleTaskInterfaces, const FGenericVarContainer Var, const float AutoFinishTime)
{
	UAsyncSimpleSingleTaskAction* Node = NewObject<UAsyncSimpleSingleTaskAction>();
	Node->WorldContextObject = WorldContext;
	Node->RegisterWithGameInstance(WorldContext);
	Node->VarContainer = Var;
	Node->Time = AutoFinishTime;
	SimpleTaskInterfaces = Node;
	return Node;
}

bool UAsyncSimpleSingleTaskAction::AddToTaskCheck(FString& FailReason)
{
	if(InTask)
	{
		FailReason = FailReasons::InTask;
		return false;
	}
	if(Activated)
	{
		FailReason = FailReasons::Activated;
		return false;
	}
	if(Finished)
	{
		FailReason = FailReasons::SubFinished;
		return false;
	}
	InTask = true;

	return true;
}

FString UAsyncSimpleSingleTaskAction::Start()
{
	if(Activated)
	{
		return FailReasons::Activated;
	}
	if(Finished)
	{
		return FailReasons::SelfFinished;
	}
	if(InTask)
	{
		return FailReasons::InTask;
	}
	OnStart();
	return FString();
}

void UAsyncSimpleSingleTaskAction::Break()
{
	if(Finished) return;
	OnCompleted.Broadcast();
	OnCompleted.Clear();
	OnCalled.Clear();
	Finished = true;
	SetReadyToDestroy();
}

void UAsyncSimpleSingleTaskAction::OnStart()
{
	Activated = true;
	OnCalled.Broadcast(VarContainer);
	if(Time>0)
	{
		FTimerManager& TimerManager = GEngine->GetWorldFromContextObject(WorldContextObject,EGetWorldErrorMode::LogAndReturnNull)->GetTimerManager();
		FTimerHandle Handle;
		TimerManager.SetTimer(Handle,
			FTimerDelegate::CreateLambda([this]()
			{
				Break();
			}),
			Time,
			false);
	}
	else if(Time==0)
	{
		Break();
	}
}

UAsyncSimpleMultipleTaskAction* UAsyncSimpleMultipleTaskAction::SimpleMultipleTimesTask(UObject* WorldContext,TScriptInterface<IAsyncForInterfaces_Base>& SimpleTaskInterfaces, const FGenericVarContainer Var)
{
	UAsyncSimpleMultipleTaskAction* Node = NewObject<UAsyncSimpleMultipleTaskAction>();
	Node->WorldContextObject = WorldContext;
	Node->RegisterWithGameInstance(WorldContext);
	Node->VarContainer = Var;
	SimpleTaskInterfaces = Node;
	return Node;
}

bool UAsyncSimpleMultipleTaskAction::AddToTaskCheck(FString& FailReason)
{
	FailReason = FailReasons::Persistent;
	return false;
}

FString UAsyncSimpleMultipleTaskAction::Start()
{
	if(Finished)
	{
		return FailReasons::SelfFinished;
	}
	OnCalled.Broadcast(VarContainer);
	return FString();
}

void UAsyncSimpleMultipleTaskAction::Break()
{
	if(Finished) return;
	OnCompleted.Broadcast();
	OnCompleted.Clear();
	OnCalled.Clear();
	Finished = true;
	SetReadyToDestroy();
}

