// Copyright lurongjiu 2026 All Rights Reserved.

#pragma once

#include "CoreMinimal.h"


#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 5
//#include "StructUtils/InstancedStruct.h"
#include "StructUtils/PropertyBag.h"
#else
#include "PropertyBag.h"
#endif


#include "Kismet/BlueprintFunctionLibrary.h"
#include "GenericTypeHelperLibrary.generated.h"


USTRUCT(BlueprintType)
struct FGenericVarContainer
{
	GENERATED_BODY()

	UPROPERTY()
	FInstancedPropertyBag Bag;

	//todo:未来支持interface
	/*UPROPERTY()
	TScriptInterface<IInterface> Interface;*/

	void Add(const FProperty* InProperty);
	const FProperty* Get();
};

UENUM()
enum class EGenericVarResult : uint8
{
	Valid,
	NotValid,
};

UCLASS()
class GENERICTYPEHELPER_API UGenericTypeHelperLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:

	/**
	* Make a GenericVarContainer from variable,GenericVarContainer maintains a reference to the original variable instead of converting it to another type.
	*
	*/
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Utilities|Generic Var", meta=(BlueprintInternalUseOnly="true", CustomStructureParam = "Var", CompactNodeTitle = "MakeContainer", NativeMakeFunc))
	static FGenericVarContainer MakeContainerFromVar(const int32& Var);
	/**
	* Make a GenericVarContainer array from variable array.
	*
	*/
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Utilities|Generic Var", meta=(ArrayParm = "VarArr", CompactNodeTitle = "MakeContainers", NativeMakeFunc))
	static TArray<FGenericVarContainer> MakeContainerFromVarArr(const TArray<int32>& VarArr);
	/**
	* Get variable from GenericVarContainer.
	*
	* @param Recursion If the contained value is another GenericVarContainer, recursively retrieve the underlying variable.
	*/
	UFUNCTION(BlueprintCallable, CustomThunk, Category = "Utilities|Generic Var", meta=(BlueprintInternalUseOnly="true", CustomStructureParam = "Var", ExpandEnumAsExecs = "ExecResult"))
	static void GetVarFromContainer(EGenericVarResult& ExecResult, UPARAM(Ref) const FGenericVarContainer& VarContainer, int32& Var, const bool Recursion = true);
	
	DECLARE_FUNCTION(execMakeContainerFromVar);
	DECLARE_FUNCTION(execMakeContainerFromVarArr);
	DECLARE_FUNCTION(execGetVarFromContainer);
	

private:
	static bool PackVarToContainer(FProperty* ValueProp, void* ValuePtr, FGenericVarContainer& OutContainer);
	static bool ExtractVarFromContainer(FGenericVarContainer& Container, FProperty* DestProp, void* DestPtr, bool Recursion);
	//object和struct识别输出为父类时类型正确
	static bool IsOrIsChildOf(const FProperty* ContainerValue, const FProperty* OutputValue);
	//解嵌套结构
	static const FProperty* ResolveFinalProperty(const FProperty* InProp, void*& InOutPtr);
};
