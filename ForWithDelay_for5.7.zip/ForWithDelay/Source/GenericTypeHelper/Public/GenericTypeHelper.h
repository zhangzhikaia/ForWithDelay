// Copyright lurongjiu 2026 All Rights Reserved.

#pragma once
#include "Engine/Engine.h"
#include "Modules/ModuleManager.h"

class FGenericTypeHelperModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	
};

namespace DebugHelper
{
	static void Print(const FString& message, FColor color = FColor::Blue)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s"), *message);
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message);
		}
	}
	static void Print(int message, FColor color = FColor::Blue)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s"), *FString::FromInt(message));
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, FString::FromInt(message));
		}
	}
}