// Copyright lurongjiu 2026 All Rights Reserved.


#include "GenericTypeHelperLibrary.h"

#include "GenericTypeHelper.h"

#define P_GET_ARRAY_PRV(ArrayAddr,ArrayProp)\
Stack.MostRecentProperty = nullptr;\
Stack.StepCompiledIn<FArrayProperty>(NULL);\
void* ArrayAddr = Stack.MostRecentPropertyAddress;\
FArrayProperty* ArrayProp = CastField<FArrayProperty>(Stack.MostRecentProperty);\

#define P_GET_PPT_PRV(PPTAddr,PPTProp)\
Stack.StepCompiledIn<FProperty>(nullptr);\
void* PPTAddr = Stack.MostRecentPropertyAddress;\
FProperty* PPTProp = Stack.MostRecentProperty;\


EPropertyBagAlterationResult FGenericVarContainer::Add(const FProperty* InProperty)
{
	return Bag.AddProperty(TEXT("Value"), InProperty);
}

const FProperty* FGenericVarContainer::Get()
{
	if(const FPropertyBagPropertyDesc* desc = Bag.FindPropertyDescByName(TEXT("Value")))
	{
		return desc->CachedProperty;
	}

	return nullptr;
}

FGenericVarContainer UGenericTypeHelperLibrary::MakeContainerFromVar(const int32& Var)
{
	checkNoEntry()
	return FGenericVarContainer();
}

TArray<FGenericVarContainer> UGenericTypeHelperLibrary::MakeContainerFromVarArr(const TArray<int32>& VarArr)
{
	checkNoEntry()
	return {};
}

void UGenericTypeHelperLibrary::GetVarFromContainer(EGenericVarResult& ExecResult, const FGenericVarContainer& ValueContainer, int32& Var, const bool Recursion)
{
	checkNoEntry()
}

DEFINE_FUNCTION(UGenericTypeHelperLibrary::execMakeContainerFromVar)
{
	P_GET_PPT_PRV(ValuePtr, ValueProp);
	
	P_FINISH;

	FGenericVarContainer Result;

	if(PackVarToContainer(ValueProp, ValuePtr, Result))
	{
		*(FGenericVarContainer*)RESULT_PARAM = MoveTemp(Result);
	}
	else
	{
		*(FGenericVarContainer*)RESULT_PARAM = Result;
	}
}

DEFINE_FUNCTION(UGenericTypeHelperLibrary::execMakeContainerFromVarArr)
{
	P_GET_ARRAY_PRV(ArrayAddr,ArrayProp);
	//结束获取
	P_FINISH;
	//开始数组操作标记
	P_NATIVE_BEGIN;
	
	TArray<FGenericVarContainer>& OutArray = *(TArray<FGenericVarContainer>*)RESULT_PARAM;
	OutArray.Reset();
	
	if(ArrayProp && ArrayAddr)
	{
		FScriptArrayHelper Helper(ArrayProp, ArrayAddr);
		for (int32 i = 0; i < Helper.Num(); ++i)
		{
			void* ElemPtr = Helper.GetRawPtr(i);
			FProperty* InnerProp = ArrayProp->Inner;

			FGenericVarContainer Container;
			PackVarToContainer(InnerProp, ElemPtr, Container);

			OutArray.Add(MoveTemp(Container));
		}
	}
	//结束数组操作标记
	P_NATIVE_END;
}


DEFINE_FUNCTION(UGenericTypeHelperLibrary::execGetVarFromContainer)
{
	P_GET_ENUM_REF(EGenericVarResult, ExecResult);
	P_GET_STRUCT_REF(FGenericVarContainer, ValueContainer);
	
	Stack.MostRecentPropertyAddress = nullptr;
	Stack.MostRecentPropertyContainer = nullptr;
	P_GET_PPT_PRV(DestPtr, DestProp);
	P_GET_UBOOL(Recursion);
	
	P_FINISH;
	
	ExecResult = ExtractVarFromContainer(ValueContainer, DestProp, DestPtr, Recursion) ? EGenericVarResult::Valid : EGenericVarResult::NotValid;
	
}

bool UGenericTypeHelperLibrary::PackVarToContainer(FProperty* ValueProp, void* ValuePtr, FGenericVarContainer& OutContainer)
{
	if (ValueProp && ValuePtr)
	{
		FGenericVarContainer Result;
		Result.Add(ValueProp);
		if (const FProperty* BagProperty = Result.Get())
		{
			FStructView BagView = Result.Bag.GetMutableValue();

			void* DestPtr = BagProperty->ContainerPtrToValuePtr<void>(BagView.GetMemory());
			
			if (DestPtr)
			{
				if (FObjectProperty* ObjProp = CastField<FObjectProperty>(ValueProp))
				{
					UObject* Obj = ObjProp->GetObjectPropertyValue(ValuePtr);

					if (!IsValid(Obj))
					{
						return false;
					}
				}
				
				BagProperty->CopyCompleteValue(DestPtr, ValuePtr);
			}
		}
		
		OutContainer = FGenericVarContainer(Result);
		return true;
	}
	return false;
}

bool UGenericTypeHelperLibrary::ExtractVarFromContainer(FGenericVarContainer& Container, FProperty* DestProp, void* DestPtr, const bool Recursion)
{
	if (DestProp && DestPtr)
	{
		if(const FProperty* BagProperty = Container.Get())
		{
			FStructView BagView = Container.Bag.GetMutableValue();
			void* SrcPtr = BagProperty->ContainerPtrToValuePtr<void>(BagView.GetMemory());
			if(Recursion)
			{
				BagProperty = ResolveFinalProperty(BagProperty,SrcPtr);
			}
		
			if(IsOrIsChildOf(BagProperty, DestProp))
			{
				if (SrcPtr)
				{
					if (FObjectProperty* ObjProp = CastField<FObjectProperty>(DestProp))
					{
						UObject* Obj = ObjProp->GetObjectPropertyValue(SrcPtr);
						if (!IsValid(Obj))
						{
							return false;
						}
					}
					// CopyCompleteValue 会根据 DestProp 类型做正确复制
					DestProp->CopyCompleteValue(DestPtr, SrcPtr);
					return true;
				}
			}
		}
	}
	return false;
}

bool UGenericTypeHelperLibrary::IsOrIsChildOf(const FProperty* ContainerValue, const FProperty* OutputValue)
{
	if(ContainerValue->SameType(OutputValue))
	{
		return true;
	}
	
	//检查Container是子类,output是父类,必定成功,否则不一定.不帮用户cast
	if (const FObjectProperty* Output = CastField<FObjectProperty>(OutputValue))
	{
		if (const FObjectProperty* Container = CastField<FObjectProperty>(ContainerValue))
		{
			return Container->PropertyClass->IsChildOf(Output->PropertyClass);
		}
	}

	if (const FStructProperty* Output = CastField<FStructProperty>(OutputValue))
	{
		if (const FStructProperty* Container = CastField<FStructProperty>(ContainerValue))
		{
			return Container->Struct->IsChildOf(Output->Struct);
		}
	}
	
	//todo:支持interface类型
	/*if (const FInterfaceProperty* Output = CastField<FInterfaceProperty>(OutputValue))
	{
		if (const FObjectProperty* Container = CastField<FObjectProperty>(ContainerValue))
		{
			return Container->PropertyClass->ImplementsInterface(Output->InterfaceClass);
		}
	}*/
	
	return false;
}

const FProperty* UGenericTypeHelperLibrary::ResolveFinalProperty(const FProperty* InProp, void*& InOutPtr)
{
	const FProperty* CurrentProp = InProp;
	void* CurrentPtr = InOutPtr;

	while (true)
	{
		// 1. 必须是 Struct（因为 Container 是 struct）
		const FStructProperty* StructProp = CastField<FStructProperty>(CurrentProp);
		if (!StructProp)
		{
			break;
		}

		// 2. 判断是不是你的 FGenericVarContainer
		if (StructProp->Struct != FGenericVarContainer::StaticStruct())
		{
			break;
		}

		// 3. 取出 container
		FGenericVarContainer* Container = (FGenericVarContainer*)CurrentPtr;
		if (!Container)
		{
			break;
		}

		// 4. 找内部 Value 描述
		//const FPropertyBagPropertyDesc* Desc = Container->Bag.FindPropertyDescByName(TEXT("Value"));
		if (!Container->Get())
		{
			break;
		}

		// 5. 获取内部数据
		FStructView BagView = Container->Bag.GetMutableValue();
		void* InnerPtr = BagView.GetMemory();

		if (!InnerPtr)
		{
			break;
		}

		// 6. 进入下一层
		CurrentProp = Container->Get();
		CurrentPtr = InnerPtr;
	}

	InOutPtr = CurrentPtr;
	return CurrentProp;
}

#undef P_GET_ARRAY_PRV
#undef P_GET_PPT_PRV